<?php
if(isset($_SERVER['REQUEST_METHOD']))
      echo "Aucune méthode";
else{
      $method = $_SERVER['REQUEST_METHOD'];
      switch($method){
            case "POST":{
                  
            }
      }
}

?>