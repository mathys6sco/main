<?php

class Etudiant{

    # attributs
    private int $id;
    private string $nom;
    private string $prenom;


    # methodes
    public function __construct(){
        $num_args = func_num_args();
        switch($num_args)

        {
            case 0:
                break;

            case 2:
                $this->nom= func_get_arg(0);
                $this->prenom= func_get_arg(1);
                break;

            case 3:
                $this->id = func_get_arg(0);
                $this->nom= func_get_arg(1);
                $this->prenom= func_get_arg(2);
                break;
        }

    }

    public function set_id($id){ $this->id=$id; }
    public function set_nom($nom){ $this->nom=$nom; }
    public function set_prenom($prenom){ $this->prenom=$prenom; }

    public function get_id(){ return $this->id; }
    public function get_nom(){ return $this->nom; }
    public function get_prenom(){ return $this->prenom; }

    public function toString(){ return "Nom: ".$this->get_nom()."\nPrenom: ".$this->get_prenom();}

}

?>

