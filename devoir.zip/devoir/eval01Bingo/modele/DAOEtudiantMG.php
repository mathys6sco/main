<?php
include_once('../libs/pdo2.php');
include_once('../global/config.php');
include_once('../entityMG/etudiant.php');


function getLesEtudiantsMG(){
    $bd = PDO2::getInstance();
    $send = $bd->prepare("SELECT id, nom, prenom FROM Etudiant;");
    $send->execute();
    $sent = $send->fetchAll(PDO::FETCH_CLASS, 'Etudiant');
    return $sent;
}

function getUnEtudiantMG(int $id){
    $bd = PDO2::getInstance();
    $send = $bd->prepare("SELECT id, nom, prenom FROM Etudiant WHERE id=:id;");
    $to_send = array('id'=>$id);
    $send->execute($to_send);
    $etu = $send->fetchAll(PDO::FETCH_CLASS, 'Etudiant');
    return $etu;
}

function addUnEtudiantMG(string $nom,string $prenom){
    $bd = PDO2::getInstance();
    $send = $bd->prepare("INSERT INTO Etudiant (id, nom, prenom) VALUES (NULL, :nom, :prenom);");
    $etu = array('nom'=>$nom,'prenom'=>$prenom);
    $send->execute($etu);
}

function updateUnEtudiantMG($etu){
    $bd = PDO2::getInstance();
    $send = $bd->prepare("UPDATE Etudiant SET nom=:nom,prenom=:prenom WHERE id=:id;");
    $to_send = array('id'=>$etu->get_id(),'nom'=>$etu->get_nom(),'prenom'=>$etu->get_prenom());
    $send->execute($to_send);
}

function DeleteUnEtudiantMG(int $id){
    $bd = PDO2::getInstance();
    $send = $bd->prepare("DELETE FROM Etudiant WHERE id=:id;");
    $to_send = array('id'=>$id);
    $sent = $send->execute($to_send);
    return $sent;
}
    
?>