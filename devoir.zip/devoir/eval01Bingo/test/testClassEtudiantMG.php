<?php
include_once('../entityMG/etudiant.php');

$nvx1 = new Etudiant("Ji Lon", "Matis");

echo '$nvx1->get_nom() // renvoie : '. $nvx1->get_nom();
echo '<br>$nvx1->get_prenom() // renvoie : '. $nvx1->get_prenom();

$nvx1->set_id(1);
echo '<br><br>$nvx1->get_id() // renvoie : '. $nvx1->get_id();
$nvx1->set_nom('Gillon');
$nvx1->set_prenom('Mathys');
echo '<br>$nvx1->get_nom() // renvoie : '. $nvx1->get_nom();
echo '<br>$nvx1->get_prenom() // renvoie : '. $nvx1->get_prenom();





?>