<?php

include '../global/config.php';
include '../'.CHEMIN_LIB.'pdo2.php';

 var_dump(PDO2::getInstance());
 
 
?>
