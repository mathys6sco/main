<?php
include_once('../modele/DAOEtudiantMG.php');

echo "<h2>Questions 8 :</h2>";

#85b

$id = 3;
$r = DeleteUnEtudiantMG($id);
if($r){
    echo "Supprimé l'id = ".$id;
}

?>