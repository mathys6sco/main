<?php
include_once('../modele/DAOEtudiantMG.php');

echo "<h2>Questions 8 :</h2>";

#82b
$tab = getLesEtudiantsMG();
foreach($tab as $el){
    echo $el->toString();
}

?>