<?php
include_once('../modele/DAOEtudiantMG.php');

echo "<h2>Questions 8 :</h2>";

#83b
$etu = getUnEtudiantMG(1);
echo $etu->toString();

?>