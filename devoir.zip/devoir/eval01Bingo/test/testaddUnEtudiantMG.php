<?php
include_once('../modele/DAOEtudiantMG.php');

echo "<h2>Questions 8 :</h2>";

#84b
addUnEtudiantMG("De La Place","Stephane");
$tab = getLesEtudiantsMG();
foreach($tab as $el){
    $el->toString();
    echo "<br>";
}

?>