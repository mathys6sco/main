<?php
include_once('../modele/DAOEtudiantMG.php');

echo "<h2>Questions 8 :</h2>";

#85b

$etu = getUnEtudiantMG(1);
$etu->toString();

echo "<br><br>";

$etudiant = new Etudiant(1,"J lon","Mathys");
updateUnEtudiantMG($etudiant);

$etu = getUnEtudiantMG(1);
$etu->toString();

?>